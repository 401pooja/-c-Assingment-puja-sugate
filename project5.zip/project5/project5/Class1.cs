﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class Class1
    {
        static void Main()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 40, 50 };
            for(int i=0;i<2;i++)
            {
                foreach(int temp in nums[i])
                {
                    Console.Write("{0}\t",temp);
                }
            }

        }
    }
}
