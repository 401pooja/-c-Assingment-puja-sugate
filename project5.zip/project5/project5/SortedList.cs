﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class SortedListDemo
    {
        static void Main()
        {
            SortedList<int, string> s = new SortedList<int, string>()
            {
                {20,"one" },{10,"two"},{15,"hundred"}
            };

            Console.WriteLine($"Count is {s.Count}");
            foreach(int key in s.Keys)
            {
                Console.WriteLine($"key is {key} and value is {s[key]}");
            }

            if(s.Remove(10))
            {
                Console.WriteLine($" after removing Count is {s.Count}");
            }

            foreach (int key in s.Keys)
            {
                Console.WriteLine($"key is {key} and value is {s[key]}");
            }
        }

    }
}
