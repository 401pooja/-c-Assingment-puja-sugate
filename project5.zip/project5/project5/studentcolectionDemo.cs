﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class studentcolectionDemo
    {
        static void  Main()
        {
            List<Student> s = new List<Student>()
            {
                new Student {Rollno=100,Name="Scott"},
                  new Student {Rollno=101,Name="Tiger"},
            };

            //Student s1 = new Student() { Rollno = 100, Name = "Scott" };
            //Student s1 = new Student() { Rollno = 101, Name = "Tiger" };
            //s.Add(s1);

            foreach (Student std in s)
            {
                Console.WriteLine($"Rollno is{std.Rollno} and Name is {std.Name}");
            }
        }
    }
}
