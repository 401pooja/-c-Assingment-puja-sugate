﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class genricdemo
    {
        static void Main()
        {
            Queue<int> q = new Queue<int>();
            q.Enqueue(12);
            //q.Enqueue("abc");//error

            Stack<int> stk = new Stack<int>();
            stk.Push(10);
            stk.Push(20);
            //stk.Push("abc");//error
        }
    }
}
