﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class queuedemo
    {
        static void Main()
        {
            Queue book = new Queue();
            book.Enqueue(123);
            book.Enqueue(124);
            book.Enqueue(125);
            foreach(int temp in book)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("After removing {0}", book.Dequeue());
            foreach (int temp in book)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("next element to be remove is{0}", book.Peek());

            Console.WriteLine("***stack****");
            Stack stk = new Stack();
            stk.Push(123);
            stk.Push(124);
            stk.Push(125);
            foreach (int temp in stk)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("next element to be remove is{0}", stk.Peek());

            stk.Pop();
            foreach (int temp in stk)
            {
                Console.WriteLine(temp);
            }





        }
    }
}
