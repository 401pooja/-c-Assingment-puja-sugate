﻿using System;

using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class arraylistdemo
    {
        static void Main()
        {
            ArrayList std = new ArrayList();
            std.Add(100);
            std.Add("Scott");
            std.Add("s@gmail.com");
            std.Add('F');
            std.Add(true);
            std.Capacity = std.Count;
            Console.WriteLine("Total count is {0} capacity {1}", std.Count,std.Capacity);
            foreach(var temp in std)
            {
                Console.WriteLine(temp);
            }
            std.Remove("Scott");
            std.Capacity=std.Count;
            Console.WriteLine("After removing name");
            foreach (var temp in std)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Total count is {0} capacity {1}", std.Count, std.Capacity);
            Console.WriteLine("100 is there?{0}",std.Contains(100));
            std.Clear();
            std.Capacity = std.Count;
            Console.WriteLine("After clering all elements");
            Console.WriteLine("Total count is {0} capacity {1}", std.Count, std.Capacity);
        }
    }
}
