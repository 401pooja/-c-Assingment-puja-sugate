﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class arrayclss
    {
        static void Main()
        {
            int[] nums = { 11, 3, 1, 9, 12 };
            int[,] num1= new int[2, 3];
            int[,] dums1 = new int[2, 4];
            Console.WriteLine("upperbound for num1(0) is {0} and for num1(1) is {1}", num1.GetUpperBound(0), num1.GetUpperBound(1));
            Console.WriteLine("Numbers of dim are{0}", num1.Rank);
            Array.Copy(nums, dums1, 5);
            Console.WriteLine("after copyimh elements nums to dums");
            Array.Sort(dums1);


        }
        

    }
}
