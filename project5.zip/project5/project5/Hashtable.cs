﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class Hashtabled
    {
        static void Main()
        {
            Hashtable gst = new Hashtable();
            gst.Add("maharastra", 27);
            gst.Add("gujrat", 24);
            gst.Add("delhi", 12);
            string state = " gujrat";
            if(gst[(state).ToLowerInvariant()]==null)
                    {
                Console.WriteLine("invalid sate");
            }
            else
            {
                Console.WriteLine("gst code for gujrat is {0}", gst[(state).ToLowerInvariant()]);
            }
            //Console.WriteLine("gst code for gujrat is {0}",gst[(state).ToLowerInvariant()]);


            gst["delhi"] = 11;
            Console.WriteLine("gst code for gujrat is {0}", gst[("delhi").ToLowerInvariant()]);
            Console.WriteLine("All keys");
            foreach(var v in gst.Keys)
            {
                Console.WriteLine("key={0} and value={1}", v, gst[v]);

            }

            gst.Remove("delhi");
            Console.WriteLine("After removing delhi");
            foreach (var v in gst.Keys)
            {
                Console.WriteLine("key={0} and value={1}", v, gst[v]);

            }




        }
    }
}
