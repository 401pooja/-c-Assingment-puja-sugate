﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class ListDemo
    {
        static void Main()
        {
            //List<int> mylist = new List<int>();
            IList<int> mylist = new List<int>();
            mylist.Add(10);
            mylist.Add(20);
            mylist.Add(30);
            //Console.WriteLine("Count is{0}", mylist.Count);
            Console.WriteLine($"Count is {mylist.Count}");

            foreach (int temp in mylist)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("After removing 20");
            if (mylist.Remove(20))
            {
                Console.WriteLine($"Count is {mylist.Count}");
            }
           

            foreach (int temp in mylist)
            {
                Console.WriteLine(temp);
            }

        }
    }
}
