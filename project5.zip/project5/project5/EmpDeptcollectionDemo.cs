﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class EmpDeptcollectionDemo
    {
        static void Main()
        {
            Dictionary<Department, employee> de = new Dictionary<Department, employee>()
            {
                { new Department {DeptCode=101 },new employee {EmpId=200,EmpName="pooja",DeptCode=101} },
                { new Department {DeptCode=102 },new employee {EmpId=201,EmpName="ayushi",DeptCode=102} }
            };

            foreach (var v in de.Keys)
            {
                Console.WriteLine($"value is {de[v].EmpId} {de[v].EmpName} {de[v].DeptCode}");
            }
        }
    }
}
