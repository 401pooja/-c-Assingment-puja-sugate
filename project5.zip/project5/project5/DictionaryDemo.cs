﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class DictionaryDemo
    {
        static void Main()
        {
            //Dictionary<int, string> mypairs = new Dictionary<int, string>();
            Dictionary<int, string> mypairs = new Dictionary<int, string>(){
                { 1, "one"},{2, "Two"},{100, "hundres"}
            };
            //mypairs.Add(1, "one");
            //mypairs.Add(2, "Two");
            //mypairs.Add(100, "hundres");
            Console.WriteLine($"Cont is:{mypairs.Count}");
            Console.WriteLine($"value is{mypairs[2]}");
            if(mypairs.Remove(2))
            {
                Console.WriteLine($"Cont is:{mypairs.Count}");
            }

            foreach(var v in mypairs.Keys)
            {
                Console.WriteLine($"key is {v} and value is {mypairs[v]}");
            }
        }
    }
}
