﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class arrayclassdemo
    {

        static void Main()
        {

            int[] num = { 11, 3, 1, 9, 12 };
            int[] dums = new int[5];
            num.CopyTo(dums, 0);
            Console.WriteLine("After copying elements nums to dums")
            foreach(int temp in dums)
            {
                Console.WriteLine(temp);
            }

        }
    }
}
