﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project5
{
    class employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int DeptCode{ get; set; }
    }
}
