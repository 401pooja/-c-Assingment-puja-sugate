﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
     public class GST
    {
        double rate;
        double amount;
        double TotalAmount;
        double interest;

        public GST(double rate,double amount)
        {
            this.rate = rate;
            this.amount = amount;
            interest = amount * rate / 100;
            TotalAmount = interest + amount;
        }

        public string Display()
        {
            return $"Gst interest is={interest}" +
                $"Total Amount={TotalAmount}";
        }
    }
}
