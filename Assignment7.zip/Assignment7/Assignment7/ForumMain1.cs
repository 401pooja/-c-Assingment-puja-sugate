﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class ForumMain1
    {
        static void Main()
        {
            Console.WriteLine("Enter the id");
            int i = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the name");
            string n = Console.ReadLine();

            Console.WriteLine("Enter the emailId");
            string s = Console.ReadLine();

            Console.WriteLine("Enter the date of birth");
            string d = Console.ReadLine();

            Forum f = new Forum(i,n,s,d);
            Console.WriteLine(f.ToString());


            Console.ReadLine();
        }
    }
}
