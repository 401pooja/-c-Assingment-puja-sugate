﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    abstract class Computer
    {
        public Computer()
        {
            Console.WriteLine("Default constructor of computer");
        }

        public string BootUp()
        {
            return "Computer is bootup";
        }

        public string ShutDown()
        {
            return "Computer is shutdown";
        }

        //public abstract string start(string type);
    }

    /*class Laptop: Computer
    {
        public override string start(string type)
        {
            return $"this will start using{type}";
        }

    }*/

    class SuperComputer : Computer
    {
        public SuperComputer()
        {
            Console.WriteLine("Default super computer");
        }
    }

    class MainfraimComputer : Computer
    {
        public MainfraimComputer()
        {
            Console.WriteLine("Default mainframe computer");
        }
    }

    class MicroComputer : Computer
    {
        public MicroComputer()
        {
            Console.WriteLine("Default micro computer");
        }
    }

    sealed class pen
    {
        public string StartWriting()
        {
            return "start writing";
        }

        public string StoptWriting()
        {
            return "stop writing";
        }
    }

    class MainAbstarct
    {
        static void Main()
        {
            SuperComputer s = new SuperComputer();
            Console.WriteLine(s.BootUp());
            Console.WriteLine(s.ShutDown());
            // Console.WriteLine(m.start("key"));

            MainfraimComputer m = new MainfraimComputer();
            Console.WriteLine(m.BootUp());
            Console.WriteLine(m.ShutDown());

            MicroComputer m1 = new MicroComputer();
            Console.WriteLine(m1.BootUp());
            Console.WriteLine(m1.ShutDown());

            pen p = new pen();
            Console.WriteLine(p.StartWriting());
            Console.WriteLine(p.StoptWriting());


        }
    }
}
