﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Forum
    {
        
            private long id;
            private string Name;
            private string EmailId;
            private string Dateofbirth;
           

            public Forum()//constructor
            {
                Console.WriteLine("Default constructer of Forum");
            }

            public Forum(long id,string Name, string EmailId, string Dateofbirth)
            {
                this.id = id;
                this.Name = Name;
                this.EmailId= EmailId;
                this.Dateofbirth = Dateofbirth;
                

            }
            public override string ToString()
            {
            return ($"Id={id}" +
                $" \nName={Name} " +
                $"\nEmail id={EmailId} " +
                $"\nDate of birth={Dateofbirth}");
                   
            }

        
    }
}
